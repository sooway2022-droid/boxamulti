# BOX 실시간 LTE 무전 통화 - 안드로이드 설치 패키지

## 포함 파일 구성
- `www/index.html` : 실시간 상시 양방향 무전 통화 앱 전체 소스 (로딩 2초, 닉네임 검증, 상단 70% 채널목록, 최대 5인 P2P 음성통화, 입장 TTS 음성안내, 하단 BOX APPAREL / SPORT WEAR 로고 적용)
- `www/icon-512.png` : 무전기 2개 심플·세련된 디자인의 안드로이드 앱 아이콘 (512x512)
- `capacitor.config.json` & `package.json` : 안드로이드 네이티브(APK) 변환 설정 파일
- `.github/workflows/build-apk.yml` : 안드로이드 스튜디오 설치 없이 GitHub에서 클릭 한 번으로 `.apk` 설치 파일을 자동 생성하는 빌드 스크립트

---

## 방법 1. 안드로이드 스튜디오 없이 2분 만에 `.apk` 설치 파일 생성하기 (가장 쉬움)
1. [GitHub](https://github.com)에 무료 로그인 후 새 저장소(Repository)를 만듭니다.
2. 이 압축 파일의 모든 폴더와 파일을 업로드합니다.
3. 상단 **Actions** 탭 → **Build Android APK** → **Run workflow** 버튼을 누릅니다.
4. 약 2분 뒤 빌드가 완료되면 아래 Artifacts에서 **`BOX_PTT_Android_APK`**를 다운로드하여 스마트폰에 설치하면 됩니다.

## 방법 2. 내 PC (Android Studio)에서 직접 `.apk` 빌드하기
1. 터미널에서 압축을 푼 폴더로 이동합니다.
2. 아래 명령어를 순서대로 실행합니다:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
3. 열린 Android Studio 상단 메뉴에서 **Build > Build Bundle(s) / APK(s) > Build APK(s)**를 클릭하면 `.apk` 설치 파일이 생성됩니다.
